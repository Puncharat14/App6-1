import React from "react";
import Home from "./page/home";

function App() {
 return(
  <Home />
 )
}

export default App;